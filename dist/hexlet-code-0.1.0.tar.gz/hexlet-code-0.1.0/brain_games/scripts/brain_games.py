#!/usr/bin/env python

def greet(where):
    print('Welcome to the {}!'.format(where))

def main():
    greet('Brain Games')

if __name__ == '__main__':
    main()